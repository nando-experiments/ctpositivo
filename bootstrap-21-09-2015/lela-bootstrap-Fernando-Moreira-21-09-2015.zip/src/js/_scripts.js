;(function($) {

  $(function() {

    // your code here..

  });

})(jQuery);